
import { GoogleGenAI, Type } from "@google/genai";
import { DetectionResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * System Prompt for Sentinel X Core Intelligence
 */
const SYSTEM_INSTRUCTION = `You are Sentinel X, an expert AI forensic analyst specialized in detecting scam phone calls and social engineering tactics.
Your task is to analyze call audio/transcripts and provide a high-fidelity fraud risk assessment.
Look for:
1. Pressure tactics (urgency, threats, fear).
2. Unusual requests (OTP, remote access, gift cards, crypto).
3. Spoofing indicators (claiming to be from banks, government agencies, or tech support).
4. Social engineering patterns (rapport building then pivot to sensitive data).

Return output STRICTLY in JSON format.`;

export const analyzeCallAudio = async (base64Audio: string, mimeType: string): Promise<DetectionResult> => {
  // Use Gemini 3 for its advanced reasoning and multimodal capabilities
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      {
        inlineData: {
          data: base64Audio,
          mimeType: mimeType
        }
      },
      {
        text: `Analyze this call recording for scam potential. 
        First, provide a verbatim transcription identifying 'Caller' and 'Receiver'.
        Then, perform a deep forensic analysis to determine if this is a scam.
        
        Return the result in the following JSON schema:
        {
          "scam_probability": number (0-100),
          "scam_type": string,
          "dangerous_keywords": string[],
          "reason": string,
          "transcript": string
        }`
      }
    ],
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          scam_probability: { type: Type.NUMBER },
          scam_type: { type: Type.STRING },
          dangerous_keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
          reason: { type: Type.STRING },
          transcript: { type: Type.STRING }
        },
        required: ["scam_probability", "scam_type", "dangerous_keywords", "reason", "transcript"],
      },
    },
  });

  return JSON.parse(response.text || "{}") as DetectionResult;
};

// Legacy support if transcript is already extracted elsewhere, but analyzeCallAudio is preferred for multimodal
export const analyzeCallTranscript = async (transcript: string): Promise<DetectionResult> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this call transcript: "${transcript}"`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          scam_probability: { type: Type.NUMBER },
          scam_type: { type: Type.STRING },
          dangerous_keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
          reason: { type: Type.STRING },
          transcript: { type: Type.STRING }
        },
        required: ["scam_probability", "scam_type", "dangerous_keywords", "reason", "transcript"],
      },
    },
  });

  return JSON.parse(response.text || "{}") as DetectionResult;
};
