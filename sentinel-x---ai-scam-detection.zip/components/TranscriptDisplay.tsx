
import React from 'react';

interface TranscriptDisplayProps {
  transcript: string;
}

export const TranscriptDisplay: React.FC<TranscriptDisplayProps> = ({ transcript }) => {
  return (
    <div className="flex flex-col h-full bg-slate-900/60 rounded-[2rem] border border-slate-800 overflow-hidden backdrop-blur-xl shadow-inner">
      <div className="px-6 py-4 border-b border-slate-800 bg-slate-800/20 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-2 h-2 rounded-full bg-rose-500 mr-2 animate-pulse"></div>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Forensic Transcript Log</span>
        </div>
        <div className="flex space-x-1.5">
          <div className="w-3 h-3 rounded-full bg-slate-700/50"></div>
          <div className="w-3 h-3 rounded-full bg-slate-700/50"></div>
          <div className="w-3 h-3 rounded-full bg-slate-700/50"></div>
        </div>
      </div>
      <div className="p-8 overflow-y-auto h-full font-mono text-xs leading-relaxed text-slate-400 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent selection:bg-cyan-500/20">
        {transcript.split('\n').map((line, i) => (
          <div key={i} className="mb-3 flex group">
            <span className="text-slate-700 mr-6 w-8 text-right shrink-0 select-none group-hover:text-cyan-500/50 transition-colors">{(i + 1).toString().padStart(3, '0')}</span>
            <div className="w-full">
              {line.startsWith('Caller:') || line.startsWith('Receiver:') ? (
                <span className="text-cyan-400 font-bold mr-2 uppercase tracking-tighter opacity-80">{line.split(':')[0]}:</span>
              ) : null}
              <span className="text-slate-300">
                {line.includes(':') ? line.split(':').slice(1).join(':') : line}
              </span>
            </div>
          </div>
        ))}
        {!transcript && (
          <div className="flex flex-col items-center justify-center h-full text-slate-700 space-y-4">
            <svg className="w-12 h-12 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
            <p className="text-xs uppercase tracking-widest font-bold">Waiting for input stream...</p>
          </div>
        )}
      </div>
    </div>
  );
};
