
import React from 'react';
import { ExtendedResult } from '../App';

interface AnalyticsViewProps {
  history: ExtendedResult[];
  onBack: () => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ history, onBack }) => {
  const safeCount = history.filter(h => h.scam_probability <= 40).length;
  const suspiciousCount = history.filter(h => h.scam_probability > 40 && h.scam_probability <= 70).length;
  const highRiskCount = history.filter(h => h.scam_probability > 70).length;
  const total = history.length || 1;

  const avgScore = history.length > 0 
    ? Math.round(history.reduce((acc, curr) => acc + curr.scam_probability, 0) / history.length) 
    : 0;

  const peakThreat = history.length > 0
    ? Math.max(...history.map(h => h.scam_probability))
    : 0;

  // AI Advice based on pattern
  const getAIAdvice = () => {
    if (history.length === 0) return "Perform initial forensic scans to receive personalized threat intelligence.";
    if (highRiskCount > 0) {
      return `Critical Pattern Alert: We've identified ${highRiskCount} high-risk scam attempts recently. DO NOT share OTPs, banking credentials, or personal identifiers over voice channels. Frequent social engineering vectors detected: "${history.find(h => h.scam_probability > 70)?.scam_type || 'Unknown'}".`;
    }
    if (suspiciousCount > 0) {
      return "Heightened Caution Advised: Several calls have shown unverified psychological pressure tactics. Ensure you verify callers through official secondary channels before providing any internal information.";
    }
    return "Status Nominal: Call patterns currently align with baseline safety standards. Maintain vigilance against new social engineering variants.";
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tight flex items-center">
            <svg className="w-8 h-8 mr-4 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            Threat Intelligence
          </h2>
          <p className="text-slate-500 text-xs mt-1 uppercase tracking-widest font-black ml-12">
            AI-Driven Trend Analysis & Safety Protocols
          </p>
        </div>
        <button 
          onClick={onBack}
          className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-slate-300 text-sm font-bold rounded-2xl border border-slate-800 transition-all hover:border-cyan-500/50"
        >
          Back to Dashboard
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Core Stats */}
        <div className="lg:col-span-1 space-y-6">
          <div className="p-8 bg-slate-900/40 border border-slate-800 rounded-[2.5rem] backdrop-blur-xl">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6">Threat Distribution</h3>
            <div className="relative w-48 h-48 mx-auto flex items-center justify-center">
               <svg className="w-full h-full transform -rotate-90">
                 {/* High Risk */}
                 <circle
                   cx="96" cy="96" r="80"
                   fill="transparent" strokeWidth="20" stroke="currentColor"
                   className="text-rose-500/20"
                 />
                 <circle
                   cx="96" cy="96" r="80"
                   fill="transparent" strokeWidth="20" stroke="currentColor"
                   strokeDasharray={2 * Math.PI * 80}
                   strokeDashoffset={2 * Math.PI * 80 * (1 - highRiskCount / total)}
                   strokeLinecap="round"
                   className="text-rose-500 transition-all duration-1000 shadow-[0_0_15px_rgba(244,63,94,0.5)]"
                 />
                 {/* Suspicious */}
                 <circle
                   cx="96" cy="96" r="60"
                   fill="transparent" strokeWidth="15" stroke="currentColor"
                   className="text-amber-400/20"
                 />
                 <circle
                   cx="96" cy="96" r="60"
                   fill="transparent" strokeWidth="15" stroke="currentColor"
                   strokeDasharray={2 * Math.PI * 60}
                   strokeDashoffset={2 * Math.PI * 60 * (1 - suspiciousCount / total)}
                   strokeLinecap="round"
                   className="text-amber-400 transition-all duration-1000"
                 />
                 {/* Safe */}
                 <circle
                   cx="96" cy="96" r="40"
                   fill="transparent" strokeWidth="10" stroke="currentColor"
                   className="text-emerald-400/20"
                 />
                 <circle
                   cx="96" cy="96" r="40"
                   fill="transparent" strokeWidth="10" stroke="currentColor"
                   strokeDasharray={2 * Math.PI * 40}
                   strokeDashoffset={2 * Math.PI * 40 * (1 - safeCount / total)}
                   strokeLinecap="round"
                   className="text-emerald-400 transition-all duration-1000"
                 />
               </svg>
               <div className="absolute flex flex-col items-center">
                 <span className="text-3xl font-black text-white tracking-tighter">{history.length}</span>
                 <span className="text-[8px] font-bold text-slate-500 uppercase">Analyses</span>
               </div>
            </div>
            <div className="mt-8 grid grid-cols-3 gap-2 text-center">
               <div className="p-2 bg-emerald-500/5 rounded-xl border border-emerald-500/10">
                 <div className="text-xs font-black text-emerald-400">{safeCount}</div>
                 <div className="text-[8px] uppercase text-slate-500 font-bold">Safe</div>
               </div>
               <div className="p-2 bg-amber-400/5 rounded-xl border border-amber-400/10">
                 <div className="text-xs font-black text-amber-400">{suspiciousCount}</div>
                 <div className="text-[8px] uppercase text-slate-500 font-bold">Susp.</div>
               </div>
               <div className="p-2 bg-rose-500/5 rounded-xl border border-rose-500/10">
                 <div className="text-xs font-black text-rose-500">{highRiskCount}</div>
                 <div className="text-[8px] uppercase text-slate-500 font-bold">Scam</div>
               </div>
            </div>
          </div>

          <div className="p-8 bg-slate-900/40 border border-slate-800 rounded-[2.5rem] backdrop-blur-xl">
             <div className="flex justify-between items-end mb-6">
                <div>
                   <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-1">Average Risk</h3>
                   <div className="text-3xl font-black text-white tracking-tighter">{avgScore}%</div>
                </div>
                <div>
                   <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-1">Peak Threat</h3>
                   <div className="text-3xl font-black text-rose-500 tracking-tighter">{peakThreat}%</div>
                </div>
             </div>
             <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden shadow-inner">
               <div 
                 className="h-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)] transition-all duration-1000" 
                 style={{ width: `${avgScore}%` }}
               />
             </div>
          </div>
        </div>

        {/* Trend View */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-8 bg-slate-900/40 border border-slate-800 rounded-[2.5rem] backdrop-blur-xl h-full">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-10 flex justify-between">
              Scam Probability Timeline
              <span className="text-cyan-400">Live Data Synchronized</span>
            </h3>
            
            <div className="relative h-64 w-full flex items-end space-x-2">
               {history.length > 0 ? (
                 [...history].reverse().slice(-12).map((h, i) => (
                   <div key={i} className="flex-1 flex flex-col items-center group">
                     <div className="relative w-full flex items-end h-full">
                        <div 
                          style={{ height: `${h.scam_probability}%` }}
                          className={`w-full rounded-t-lg transition-all duration-1000 delay-${i * 50} cursor-pointer hover:brightness-125 hover:scale-x-105 ${h.scam_probability > 70 ? 'bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.3)]' : h.scam_probability > 40 ? 'bg-amber-400' : 'bg-cyan-500'}`}
                        />
                        <div className="absolute -top-6 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-800 text-[10px] font-bold px-2 py-1 rounded border border-slate-700 pointer-events-none whitespace-nowrap z-20">
                          {h.scam_probability}% Risk
                        </div>
                     </div>
                     <span className="mt-4 text-[8px] font-black text-slate-600 uppercase transform -rotate-45 h-4 block whitespace-nowrap overflow-hidden max-w-[40px]">
                       {h.fileName}
                     </span>
                   </div>
                 ))
               ) : (
                 <div className="w-full h-full flex items-center justify-center text-slate-700 text-xs italic">
                    Awaiting forensic timeline population...
                 </div>
               )}
            </div>
          </div>
        </div>
      </div>

      {/* AI Insights Section */}
      <section className="mt-8 animate-in slide-in-from-bottom-4 duration-700 delay-200">
        <div className="p-10 bg-gradient-to-br from-slate-900/60 to-slate-950/40 border border-slate-800/80 rounded-[3rem] backdrop-blur-2xl relative overflow-hidden shadow-2xl">
           <div className="absolute top-0 left-0 w-2 h-full bg-cyan-500 shadow-[0_0_20px_rgba(34,211,238,0.5)]"></div>
           <div className="relative z-10">
             <div className="flex items-center space-x-3 mb-6">
                <div className="p-2 bg-cyan-500/10 rounded-lg">
                   <svg className="w-6 h-6 text-cyan-400 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                   </svg>
                </div>
                <h3 className="text-xl font-black text-white tracking-tight uppercase tracking-[0.2em]">AI Insights & Forensic Advice</h3>
             </div>
             <p className="text-lg text-slate-300 leading-relaxed max-w-4xl font-medium italic">
               &ldquo;{getAIAdvice()}&rdquo;
             </p>
             <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="flex items-start space-x-4">
                 <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 border border-slate-700">
                    <span className="text-cyan-400 text-xs font-black">01</span>
                 </div>
                 <p className="text-xs text-slate-500 leading-relaxed font-bold uppercase tracking-wide">
                    Strict Policy: Never disclose One-Time Passwords (OTP) or private keys via inbound voice channels.
                 </p>
               </div>
               <div className="flex items-start space-x-4">
                 <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 border border-slate-700">
                    <span className="text-cyan-400 text-xs font-black">02</span>
                 </div>
                 <p className="text-xs text-slate-500 leading-relaxed font-bold uppercase tracking-wide">
                    Psychology Check: Scammers use false urgency and threats to cloud judgment. Pause and verify independently.
                 </p>
               </div>
               <div className="flex items-start space-x-4">
                 <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 border border-slate-700">
                    <span className="text-cyan-400 text-xs font-black">03</span>
                 </div>
                 <p className="text-xs text-slate-500 leading-relaxed font-bold uppercase tracking-wide">
                    Protocol: Report repeated suspicious identifiers to national fraud registries for blocklisting.
                 </p>
               </div>
             </div>
           </div>
        </div>
      </section>
    </div>
  );
};
