
import React from 'react';
import { ExtendedResult } from '../App';

interface HistoryTableProps {
  history: ExtendedResult[];
}

export const HistoryTable: React.FC<HistoryTableProps> = ({ history }) => {
  if (history.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-slate-600 italic">
        <svg className="w-16 h-16 mb-6 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-sm font-bold uppercase tracking-[0.2em]">Forensic Audit log is currently empty.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-separate border-spacing-0">
        <thead>
          <tr className="bg-slate-800/40">
            <th className="px-8 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-slate-800 rounded-tl-[2.5rem]">Date & Time of Analysis</th>
            <th className="px-8 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-slate-800">Audio File Name / ID</th>
            <th className="px-8 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-slate-800">Suspicious Score (%)</th>
            <th className="px-8 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-slate-800">Validation Score (%)</th>
            <th className="px-8 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-slate-800 rounded-tr-[2.5rem]">Reason for Classification</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/50">
          {history.map((record, idx) => (
            <tr key={idx} className="group hover:bg-white/[0.03] transition-colors">
              <td className="px-8 py-6 whitespace-nowrap">
                <span className="text-sm font-mono text-slate-300 font-bold tracking-tight">
                  {record.timestamp}
                </span>
              </td>
              <td className="px-8 py-6 whitespace-nowrap">
                <span className="text-xs font-mono text-cyan-400 bg-cyan-500/5 px-3 py-1.5 rounded-lg border border-cyan-500/20 font-bold">
                  {record.fileName}
                </span>
              </td>
              <td className="px-8 py-6 whitespace-nowrap">
                <div className="flex items-center">
                  <span className={`text-base font-black mr-3 ${record.scam_probability > 40 ? 'text-rose-500' : 'text-slate-400'}`}>
                    {record.scam_probability}%
                  </span>
                  <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden shadow-inner">
                    <div 
                      className={`h-full transition-all duration-1000 ${record.scam_probability > 40 ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]' : 'bg-slate-600'}`} 
                      style={{ width: `${record.scam_probability}%` }}
                    />
                  </div>
                </div>
              </td>
              <td className="px-8 py-6 whitespace-nowrap">
                <div className="flex items-center">
                  <span className={`text-base font-black mr-3 ${record.scam_probability <= 40 ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {100 - record.scam_probability}%
                  </span>
                  <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden shadow-inner">
                    <div 
                      className={`h-full transition-all duration-1000 ${record.scam_probability <= 40 ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]' : 'bg-slate-600'}`} 
                      style={{ width: `${100 - record.scam_probability}%` }}
                    />
                  </div>
                </div>
              </td>
              <td className="px-8 py-6">
                <p className="text-xs text-slate-400 leading-relaxed font-medium italic line-clamp-2 max-w-sm">
                  &ldquo;{record.reason}&rdquo;
                </p>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
