
import React from 'react';

interface RiskMeterProps {
  score: number;
}

export const RiskMeter: React.FC<RiskMeterProps> = ({ score }) => {
  const getColors = () => {
    if (score <= 40) return { text: 'text-emerald-400', bg: 'bg-emerald-400', glow: 'shadow-[0_0_30px_rgba(52,211,153,0.3)]', label: 'SAFE' };
    if (score <= 70) return { text: 'text-amber-400', bg: 'bg-amber-400', glow: 'shadow-[0_0_30px_rgba(251,191,36,0.3)]', label: 'SUSPICIOUS' };
    return { text: 'text-rose-500', bg: 'bg-rose-500', glow: 'shadow-[0_0_30px_rgba(244,63,94,0.3)]', label: 'HIGH RISK' };
  };

  const colors = getColors();

  return (
    <div className="flex flex-col items-center justify-center">
      <span className="text-slate-500 uppercase text-[10px] font-bold tracking-widest mb-6">Scam Risk Score</span>
      
      <div className={`relative w-56 h-56 flex items-center justify-center rounded-full ${colors.glow} transition-shadow duration-1000`}>
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="112"
            cy="112"
            r="100"
            stroke="currentColor"
            strokeWidth="4"
            fill="transparent"
            className="text-slate-800/50"
          />
          <circle
            cx="112"
            cy="112"
            r="100"
            stroke="currentColor"
            strokeWidth="12"
            strokeDasharray={2 * Math.PI * 100}
            strokeDashoffset={2 * Math.PI * 100 * (1 - score / 100)}
            strokeLinecap="round"
            fill="transparent"
            className={`${colors.text} transition-all duration-1000 ease-in-out drop-shadow-[0_0_8px_currentColor]`}
          />
        </svg>
        
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-6xl font-black ${colors.text} tracking-tighter`}>{score}%</span>
          <div className={`mt-2 px-3 py-1 rounded-full text-[10px] font-black border ${colors.text} border-current bg-current/5`}>
            {colors.label}
          </div>
        </div>
      </div>
    </div>
  );
};
