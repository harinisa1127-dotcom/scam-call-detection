
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="text-center py-12">
      <div className="inline-block relative">
        <h1 className="text-5xl md:text-6xl font-black text-white tracking-tighter mb-2">
          SENTINEL <span className="text-cyan-400">X</span>
        </h1>
        <div className="absolute -bottom-2 left-0 w-full h-1 bg-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.8)]"></div>
      </div>
      <p className="mt-6 text-slate-400 text-lg font-light tracking-widest uppercase">
        AI Powered Scam Call Detection System
      </p>
    </header>
  );
};
