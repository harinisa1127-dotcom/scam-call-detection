
import React from 'react';
import { DetectionResult } from '../types';
import { RiskMeter } from './RiskMeter';
import { TranscriptDisplay } from './TranscriptDisplay';
import { Badge } from './Badge';

interface AnalysisDashboardProps {
  result: DetectionResult;
  onReset: () => void;
}

export const AnalysisDashboard: React.FC<AnalysisDashboardProps> = ({ result, onReset }) => {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <span className="px-2 py-0.5 bg-cyan-500/10 text-cyan-400 text-[10px] font-black rounded border border-cyan-500/30">PROTOTYPE MODE</span>
            <span className="text-slate-500 text-[10px] font-bold tracking-widest">ID: {Math.floor(Math.random() * 1000000).toString(16).toUpperCase()}</span>
          </div>
          <h2 className="text-3xl font-black text-white flex items-center tracking-tight">
            Forensic Analysis Report
          </h2>
        </div>
        <button 
          onClick={onReset}
          className="group px-8 py-3 bg-slate-900 hover:bg-slate-800 text-slate-300 text-sm font-bold rounded-2xl transition-all border border-slate-800 hover:border-cyan-500/50 flex items-center"
        >
          <svg className="w-4 h-4 mr-2 group-hover:rotate-180 transition-transform duration-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          New Analysis
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Score & Core Classification */}
        <div className="lg:col-span-5 space-y-8">
          <div className="bg-slate-900/40 border border-slate-800 rounded-[3rem] p-10 backdrop-blur-xl shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M2.166 4.9L10 1.554 17.834 4.9c.452.194.734.636.734 1.127v4.713c0 4.574-3.082 8.754-7.256 9.807a1.2 1.2 0 01-.624 0C6.53 19.494 3.448 15.314 3.448 10.74V6.027c0-.491.282-.933.734-1.127zM10 3.115l-6.552 2.808v4.817c0 3.844 2.502 7.354 6 8.358 3.498-1.004 6-4.514 6-8.358V5.923L10 3.115zM10.75 8a.75.75 0 00-1.5 0v3.25a.75.75 0 001.5 0V8zm0 5.25a.75.75 0 00-1.5 0v.5a.75.75 0 001.5 0v-.5z" clipRule="evenodd" /></svg>
            </div>
            <RiskMeter score={result.scam_probability} />
            
            <div className="mt-10 pt-8 border-t border-slate-800/50">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-3">Detected Scam Type</h3>
              <div className="text-3xl font-black text-white tracking-tighter bg-gradient-to-r from-white to-slate-500 bg-clip-text text-transparent">
                {result.scam_type}
              </div>
            </div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-[2.5rem] p-8 backdrop-blur-xl">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-5">AI Forensic Logic</h3>
            <p className="text-slate-300 leading-relaxed text-lg font-medium italic">
              &ldquo;{result.reason}&rdquo;
            </p>
          </div>
        </div>

        {/* Right: Transcript & Badges */}
        <div className="lg:col-span-7 space-y-8">
          <div className="bg-slate-900/40 border border-slate-800 rounded-[2.5rem] p-8 backdrop-blur-xl">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6">Threat Keywords Flagged</h3>
            <div className="flex flex-wrap gap-3">
              {result.dangerous_keywords.map((word, i) => (
                <Badge key={i}>{word.toUpperCase()}</Badge>
              ))}
              {result.dangerous_keywords.length === 0 && (
                <span className="text-slate-600 text-sm italic">Negative. No predefined risk patterns found.</span>
              )}
            </div>
          </div>

          <div className="h-[520px] shadow-2xl">
            <TranscriptDisplay transcript={result.transcript} />
          </div>
        </div>
      </div>
    </div>
  );
};
