
import React from 'react';
import { DetectionResult } from '../types';

interface AnalysisResultsProps {
  result: DetectionResult;
}

export const AnalysisResults: React.FC<AnalysisResultsProps> = ({ result }) => {
  return (
    <div className="space-y-6">
      <div className="p-6 bg-slate-900/50 rounded-2xl border border-slate-800 backdrop-blur-sm">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Detection Analysis</h3>
        
        <div className="mb-6">
          <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Threat Classification</label>
          <div className="text-xl font-bold text-white flex items-center">
            <span className="w-2 h-2 bg-cyan-400 rounded-full mr-3 animate-pulse"></span>
            {result.scam_type}
          </div>
        </div>

        <div className="mb-6">
          <label className="text-[10px] text-slate-500 uppercase font-bold mb-2 block">Dangerous Keywords</label>
          <div className="flex flex-wrap gap-2">
            {result.dangerous_keywords.map((word, i) => (
              <span 
                key={i} 
                className="px-3 py-1 bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs font-bold rounded-full shadow-[0_0_10px_rgba(244,63,94,0.1)]"
              >
                {word}
              </span>
            ))}
            {result.dangerous_keywords.length === 0 && <span className="text-slate-600 italic text-sm">None detected</span>}
          </div>
        </div>

        <div>
          <label className="text-[10px] text-slate-500 uppercase font-bold mb-2 block">AI Logic & Justification</label>
          <div className="p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl text-slate-300 text-sm leading-relaxed">
            {result.reason}
          </div>
        </div>
      </div>
    </div>
  );
};
