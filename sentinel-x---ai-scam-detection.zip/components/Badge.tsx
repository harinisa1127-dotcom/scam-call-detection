
import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
}

export const Badge: React.FC<BadgeProps> = ({ children }) => (
  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-rose-500/10 border border-rose-500/40 text-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.15)] animate-pulse-slow">
    {children}
  </span>
);
