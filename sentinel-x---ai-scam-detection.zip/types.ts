
export interface DetectionResult {
  scam_probability: number;
  scam_type: string;
  dangerous_keywords: string[];
  reason: string;
  transcript: string;
}

export enum RiskLevel {
  SAFE = 'SAFE',
  SUSPICIOUS = 'SUSPICIOUS',
  HIGH_RISK = 'HIGH_RISK'
}
