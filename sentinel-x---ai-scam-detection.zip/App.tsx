
import React, { useState, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { AnalysisDashboard } from './components/AnalysisDashboard';
import { HistoryTable } from './components/HistoryTable';
import { AnalyticsView } from './components/AnalyticsView';
import { analyzeCallAudio } from './services/geminiService';
import { DetectionResult } from './types';

export interface ExtendedResult extends DetectionResult {
  timestamp: string;
  fileName: string;
}

const App: React.FC = () => {
  const [isSplashing, setIsSplashing] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [history, setHistory] = useState<ExtendedResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState(0);
  const [showHistoryTable, setShowHistoryTable] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [taglineIndex, setTaglineIndex] = useState(0);

  const taglines = [
    "Detect the Scam. Before It Detects You.",
    "AI That Listens, So You Don’t Get Tricked.",
    "Real-Time Protection Against Fraud Calls."
  ];

  const loadingMessages = [
    "Initializing Sentinel X Core...",
    "Decoding audio packets...",
    "Running forensic voice-to-text conversion...",
    "Identifying scam patterns via Gemini AI...",
    "Evaluating social engineering vectors...",
    "Generating risk report..."
  ];

  // Splash Screen Timer & Tagline Rotation
  useEffect(() => {
    const splashTimer = setTimeout(() => {
      setIsSplashing(false);
    }, 5000);

    const taglineTimer = setInterval(() => {
      setTaglineIndex((prev) => (prev + 1) % taglines.length);
    }, 1600);

    return () => {
      clearTimeout(splashTimer);
      clearInterval(taglineTimer);
    };
  }, []);

  // Analysis Progress Messages
  useEffect(() => {
    let interval: any;
    if (isAnalyzing) {
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev + 1) % loadingMessages.length);
      }, 2000);
    } else {
      setLoadingStep(0);
    }
    return () => clearInterval(interval);
  }, [isAnalyzing]);

  const handleReset = () => {
    setResult(null);
    setError(null);
    setIsAnalyzing(false);
    setShowHistoryTable(false);
    setShowAnalytics(false);
  };

  const processAudioFile = async (base64Audio: string, mimeType: string, fileName: string) => {
    setIsAnalyzing(true);
    setError(null);
    try {
      const analysis = await analyzeCallAudio(base64Audio, mimeType);
      const extendedAnalysis: ExtendedResult = {
        ...analysis,
        fileName: fileName,
        timestamp: new Date().toLocaleString([], { 
          year: 'numeric', 
          month: 'short', 
          day: 'numeric', 
          hour: '2-digit', 
          minute: '2-digit' 
        })
      };
      setResult(analysis);
      setHistory(prev => [extendedAnalysis, ...prev]);
    } catch (err: any) {
      console.error(err);
      setError('Analysis failed. Audio might be unsupported or restricted.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Audio = (reader.result as string).split(',')[1];
      await processAudioFile(base64Audio, file.type, file.name);
    };
    reader.readAsDataURL(file);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        const recId = `LIVE-${Math.floor(Date.now() / 1000).toString(16).toUpperCase()}`;
        reader.onload = async () => {
          const base64Audio = (reader.result as string).split(',')[1];
          await processAudioFile(base64Audio, 'audio/webm', recId);
        };
        reader.readAsDataURL(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      setError('Microphone access denied. Please enable permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  if (isSplashing) {
    return (
      <div className="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center overflow-hidden z-[100]">
        <div className="absolute inset-0 pointer-events-none opacity-20">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 blur-[120px] rounded-full animate-pulse-slow"></div>
        </div>
        
        <div className="relative z-10 text-center space-y-8 animate-in fade-in zoom-in duration-1000">
          <div className="relative inline-block">
            <h1 className="text-7xl md:text-8xl font-black text-white tracking-tighter">
              SENTINEL <span className="text-cyan-400">X</span>
            </h1>
            <div className="absolute -bottom-2 left-0 w-full h-1.5 bg-cyan-400 shadow-[0_0_30px_rgba(34,211,238,1)]"></div>
          </div>
          
          <div className="h-12 overflow-hidden">
            <p key={taglineIndex} className="text-xl md:text-2xl text-slate-400 font-light tracking-widest uppercase animate-in slide-in-from-bottom-4 fade-in duration-500">
              {taglines[taglineIndex]}
            </p>
          </div>

          <div className="pt-12 flex flex-col items-center">
            <div className="w-12 h-12 border-4 border-slate-800 border-t-cyan-400 rounded-full animate-spin mb-4"></div>
            <span className="text-slate-600 text-[10px] font-black uppercase tracking-[0.5em]">Establishing Neural Bridge...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8 selection:bg-cyan-500/30 animate-in fade-in duration-1000">
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-30">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-cyan-500/10 blur-[150px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-rose-500/5 blur-[150px] rounded-full"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex justify-between items-center px-4">
          <Header />
          <div className="flex space-x-4">
            <button 
              onClick={() => { setShowAnalytics(!showAnalytics); setShowHistoryTable(false); setResult(null); }}
              className={`p-4 rounded-full transition-all duration-300 border ${showAnalytics ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_20px_rgba(34,211,238,0.3)]' : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:text-cyan-400 hover:border-cyan-500/30'}`}
              title="Threat Intelligence Analytics"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </button>
          </div>
        </div>

        {!result && !showHistoryTable && !showAnalytics ? (
          <div className="mt-8 space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-700">
            {/* Action Cards Grid - Three Primary Sections */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* 1. Upload Audio */}
              <div 
                onClick={() => !isAnalyzing && !isRecording && fileInputRef.current?.click()}
                className={`group p-10 bg-slate-900/40 border border-slate-800 rounded-[2.5rem] backdrop-blur-xl shadow-2xl transition-all hover:border-cyan-500/50 hover:bg-slate-900/60 cursor-pointer ${isAnalyzing || isRecording ? 'opacity-50 grayscale cursor-not-allowed' : ''}`}
              >
                <div className="flex flex-col items-center text-center h-full">
                  <div className="p-6 bg-cyan-500/10 rounded-3xl mb-6 border border-cyan-500/20 group-hover:bg-cyan-500/20 group-hover:scale-110 transition-all duration-500">
                    <svg className="w-12 h-12 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">Upload Audio</h3>
                  <p className="text-slate-400 text-sm leading-relaxed mb-6">Analyze recorded call files with deep forensic intelligence.</p>
                  <div className="mt-auto px-6 py-3 bg-slate-800 rounded-full text-cyan-400 text-xs font-black uppercase tracking-widest border border-slate-700 group-hover:border-cyan-500/50 transition-all">
                    Open File
                  </div>
                </div>
                <input type="file" accept=".wav,.mp3,.m4a,.webm,.ogg" className="hidden" ref={fileInputRef} onChange={handleFileUpload} />
              </div>

              {/* 2. Live Monitoring */}
              <div 
                onClick={isRecording ? stopRecording : (!isAnalyzing ? startRecording : undefined)}
                className={`group p-10 bg-slate-900/40 border border-slate-800 rounded-[2.5rem] backdrop-blur-xl shadow-2xl transition-all hover:border-rose-500/50 hover:bg-slate-900/60 cursor-pointer ${isAnalyzing ? 'opacity-50 grayscale cursor-not-allowed' : ''} ${isRecording ? 'border-rose-500/50 bg-rose-500/5 ring-4 ring-rose-500/20' : ''}`}
              >
                <div className="flex flex-col items-center text-center h-full">
                  <div className={`p-6 rounded-3xl mb-6 border transition-all duration-500 ${isRecording ? 'bg-rose-500/20 border-rose-500/40 scale-110 animate-pulse' : 'bg-rose-500/10 border-rose-500/20 group-hover:bg-rose-500/20 group-hover:scale-110'}`}>
                    <svg className={`w-12 h-12 ${isRecording ? 'text-rose-500' : 'text-rose-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">{isRecording ? 'Capturing Live...' : 'Live Monitoring'}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed mb-6">Capture and triage active voice streams in real time.</p>
                  <div className={`mt-auto px-6 py-3 rounded-full text-xs font-black uppercase tracking-widest border transition-all ${isRecording ? 'bg-rose-500 text-white border-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.4)]' : 'bg-slate-800 text-rose-400 border-slate-700 group-hover:border-rose-500/50'}`}>
                    {isRecording ? 'Stop Stream' : 'Begin Capture'}
                  </div>
                </div>
              </div>

              {/* 3. History */}
              <div 
                onClick={() => setShowHistoryTable(true)}
                className="group p-10 bg-slate-900/40 border border-slate-800 rounded-[2.5rem] backdrop-blur-xl shadow-2xl transition-all hover:border-emerald-500/50 hover:bg-slate-900/60 cursor-pointer"
              >
                <div className="flex flex-col items-center text-center h-full">
                  <div className="p-6 bg-emerald-500/10 rounded-3xl mb-6 border border-emerald-500/20 group-hover:bg-emerald-500/20 group-hover:scale-110 transition-all duration-500">
                    <svg className="w-12 h-12 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">History</h3>
                  <p className="text-slate-400 text-sm leading-relaxed mb-6">Access a full ledger of forensic analysis and risk scores.</p>
                  <div className="mt-auto px-6 py-3 bg-slate-800 rounded-full text-emerald-400 text-xs font-black uppercase tracking-widest border border-slate-700 group-hover:border-emerald-500/50 transition-all">
                    View Ledger
                  </div>
                </div>
              </div>
            </div>

            {/* Loading Analysis Indicator */}
            {isAnalyzing && (
              <div className="max-w-xl mx-auto p-12 border border-cyan-500/20 bg-cyan-500/5 rounded-[3rem] flex flex-col items-center animate-in fade-in zoom-in duration-500 shadow-[0_0_80px_rgba(6,182,212,0.1)]">
                <div className="flex space-x-4 mb-8">
                  <div className="w-3 h-12 bg-cyan-400 animate-[bounce_1s_infinite_0ms] rounded-full shadow-[0_0_15px_rgba(34,211,238,0.5)]"></div>
                  <div className="w-3 h-12 bg-cyan-400 animate-[bounce_1s_infinite_200ms] rounded-full shadow-[0_0_15px_rgba(34,211,238,0.5)]"></div>
                  <div className="w-3 h-12 bg-cyan-400 animate-[bounce_1s_infinite_400ms] rounded-full shadow-[0_0_15px_rgba(34,211,238,0.5)]"></div>
                </div>
                <h4 className="text-2xl font-black text-white mb-2">Analyzing Transmission...</h4>
                <p className="text-cyan-400 text-[11px] font-black tracking-[0.3em] uppercase transition-all duration-500">
                  {loadingMessages[loadingStep]}
                </p>
              </div>
            )}

            {error && (
              <div className="max-w-md mx-auto p-6 bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs font-bold rounded-2xl text-center flex items-center justify-center animate-in slide-in-from-top-4">
                <svg className="w-5 h-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                {error}
              </div>
            )}
          </div>
        ) : showHistoryTable ? (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="flex justify-between items-center mb-8">
               <div>
                  <h3 className="text-3xl font-black text-white tracking-tight flex items-center">
                    <svg className="w-8 h-8 mr-4 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Analysis History
                  </h3>
                  <p className="text-slate-500 text-xs mt-1 uppercase tracking-widest font-black ml-12">
                    Comprehensive Forensic Audit Table
                  </p>
                </div>
              <button 
                onClick={handleReset}
                className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-slate-300 text-sm font-bold rounded-2xl border border-slate-800 transition-all hover:border-cyan-500/50"
              >
                Back to Dashboard
              </button>
            </div>
            <div className="bg-slate-900/20 border border-slate-800 rounded-[3rem] p-1 shadow-2xl overflow-hidden">
              <HistoryTable history={history} />
            </div>
          </div>
        ) : showAnalytics ? (
          <AnalyticsView history={history} onBack={handleReset} />
        ) : (
          <AnalysisDashboard result={result!} onReset={handleReset} />
        )}

        <footer className="mt-20 text-center text-slate-800 text-[10px] uppercase tracking-[0.5em] font-black pb-12 border-t border-slate-900 pt-12">
          SENTINEL X PROTOTYPE // HACKATHON CORE v3.1 // SECURED BY GOOGLE CLOUD AI
        </footer>
      </div>
    </div>
  );
};

export default App;
